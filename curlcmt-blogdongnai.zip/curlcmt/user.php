<?php

$email = 'duydonphuong1992@yahoo.com';
$pass = 'hoangthixuan1971';

 $UID ='hoangquochuytn';
 $location ='1';
 $type ='1';
 
?>